#!/usr/bin/env python3
"""Route a topic-intake JSON file to LIGHT / STANDARD / HIGH_RISK mode.

This helper is deterministic and intentionally conservative: it does not replace
expert judgment, but it records the default tiered-trigger decision.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

HIGH_CONSEQUENCES = {
    "thesis_chapter",
    "opening_report",
    "manuscript_submission",
    "grant_or_proposal",
    "expensive_experiment",
    "long_term_research_direction",
}
STANDARD_CONSEQUENCES = {"advisor_discussion", "group_meeting", "paper_plan"}

LIGHT_MODULES = [
    "research-topic-intake-router",
    "tiered-trigger-router",
    "prior-art-topic-filter:quick",
    "novelty-gate:quick",
    "topic-brief-writer:compact",
]

STANDARD_MODULES = [
    "research-topic-intake-router",
    "tiered-trigger-router",
    "literature-context-builder",
    "prior-art-topic-filter",
    "novelty-gate",
    "feasibility-gate",
    "collapse-test",
    "topic-arbiter",
    "topic-brief-writer",
    "workflow-archivist",
]

HIGH_MODULES = STANDARD_MODULES[:-3] + [
    "prior-art-auditor:if_needed",
    "methodology-auditor:if_needed",
    "feasibility-auditor:if_needed",
    "targeted-conflict-gate",
    "topic-arbiter",
    "topic-brief-writer",
    "workflow-archivist",
]


def route(intake: dict[str, Any]) -> dict[str, Any]:
    requested = intake.get("requested_mode")
    risk = intake.get("risk_level", "low")
    consequences = set(intake.get("decision_consequence", []))
    target_output = str(intake.get("target_output", "")).lower()
    task_types = set(intake.get("task_type", []))
    token_pref = intake.get("token_budget_preference", "balanced")

    reasons: list[str] = []
    non_reasons: list[str] = []

    if requested in {"LIGHT", "STANDARD", "HIGH_RISK"}:
        mode = requested
        reasons.append(f"User explicitly requested {requested} mode.")
    elif risk == "high" or consequences & HIGH_CONSEQUENCES:
        mode = "HIGH_RISK"
        reasons.append("Decision consequence or risk level is high.")
    elif risk == "medium" or consequences & STANDARD_CONSEQUENCES or "decision_brief" in task_types or any(x in target_output for x in ["go", "revise", "narrow", "pivot", "kill"]):
        mode = "STANDARD"
        reasons.append("Formal topic decision or advisor/paper-planning context detected.")
    else:
        mode = "LIGHT"
        reasons.append("Early-stage or low-consequence screening detected.")

    if token_pref == "minimize" and mode == "STANDARD" and not (consequences & STANDARD_CONSEQUENCES):
        non_reasons.append("Token preference is minimize; keep standard scope tight and avoid conflict unless gates escalate.")
    if mode != "HIGH_RISK":
        non_reasons.append("No high-risk consequence was detected at intake; allow later escalation if gate scores require it.")

    modules = {"LIGHT": LIGHT_MODULES, "STANDARD": STANDARD_MODULES, "HIGH_RISK": HIGH_MODULES}[mode]
    all_modules = set(HIGH_MODULES)
    skipped = sorted(all_modules - set(modules))

    return {
        "selected_mode": mode,
        "initial_risk_level": risk,
        "trigger_reasons": reasons,
        "non_trigger_reasons": non_reasons,
        "modules_to_run": modules,
        "modules_to_skip": skipped,
        "auditors_to_run": ["prior-art-auditor", "methodology-auditor", "feasibility-auditor"] if mode == "HIGH_RISK" else [],
        "escalation_allowed_later": mode != "HIGH_RISK",
        "escalation_watchpoints": [
            "prior_art_risk_score >= 4",
            "novelty_decision == fail",
            "feasibility_label in {needs_key_resource, not_feasible}",
            "collapse_test_report.survivability_label != survives",
            "user requests multi-role conflict review",
        ],
        "token_budget_note": "Use the lowest sufficient mode; do not run multi-agent conflict unless HIGH_RISK is selected or later gate escalation fires.",
        "rationale": "Deterministic routing based on user request, risk level, decision consequence, and requested output.",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path, help="Path to topic_intake.json")
    parser.add_argument("-o", "--output", type=Path, default=None, help="Path to write trigger_decision.json")
    args = parser.parse_args()

    intake = json.loads(args.input.read_text(encoding="utf-8"))
    decision = route(intake)
    text = json.dumps(decision, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)


if __name__ == "__main__":
    main()
