# AGENTS.md — Research Topic Selection Rules v3

## Mission

You are evaluating research-type paper topics, not rewriting a manuscript. Your job is to produce a defensible topic decision under evidence constraints while controlling token cost through tiered triggering.

## Non-goals

Do not run a manuscript review workflow unless the user explicitly changes the task. In this package, the following are out of scope:

- chapter-by-chapter manuscript critique;
- paragraph polishing;
- patch writing for existing drafts;
- journal-style language editing;
- figure caption rewriting;
- full-paper claim verification.

If the user provides an existing draft, use it only as one evidence source for topic definition, novelty claims, and feasibility constraints.

## Core decision labels

Use exactly one final decision:

- `GO`: topic is sufficiently novel, feasible, and bounded.
- `REVISE`: core direction is promising, but the scientific question, hypothesis, or evidence boundary needs correction.
- `NARROW`: topic is too broad; a publishable subset exists.
- `PIVOT`: current framing is weak, but adjacent framing may work.
- `KILL`: novelty, feasibility, or evidentiary support is insufficient.

## Tiered triggering policy

Always choose the lowest sufficient mode first.

### LIGHT

Use for early-stage ideas, local scope decisions, or quick comparison among several candidate topics.

Required modules:

1. `research-topic-intake-router`
2. `tiered-trigger-router`
3. `prior-art-topic-filter` in quick mode
4. `novelty-gate` in quick mode
5. `topic-brief-writer` in compact mode

Do not run multi-agent conflict in LIGHT mode.

### STANDARD

Use for a serious candidate topic that may be presented to an advisor or developed into a paper plan.

Required modules:

1. `research-topic-intake-router`
2. `tiered-trigger-router`
3. `literature-context-builder`
4. `prior-art-topic-filter`
5. `novelty-gate`
6. `feasibility-gate`
7. `collapse-test`
8. `topic-arbiter`
9. `topic-brief-writer`
10. `workflow-archivist`

Run conflict review only if escalation rules fire.

### HIGH_RISK

Use when the topic decision affects dissertation direction, opening report, expensive experiments, manuscript submission strategy, grant proposal, or a long-term research program.

Required modules:

1. all STANDARD modules
2. at least one specialized auditor when relevant:
   - `prior-art-auditor`
   - `methodology-auditor`
   - `feasibility-auditor`
3. `targeted-conflict-gate` with Advocate / Skeptic / Arbiter

## Escalation rules

Escalate from LIGHT to STANDARD if any condition is true:

- the user asks for GO / REVISE / NARROW / PIVOT / KILL;
- the topic will be shown to an advisor or used for group meeting planning;
- feasibility, dataset sufficiency, experimental control, or minimum validation is being judged;
- prior-art evidence suggests direct overlap;
- novelty is only conditional;
- the topic may become a paper, thesis chapter, or proposal.

Escalate from STANDARD to HIGH_RISK if any condition is true:

- prior-art risk score is 4 or 5;
- novelty decision is `fail`, but the user still wants to continue;
- feasibility label is `needs_key_resource` or `not_feasible`;
- collapse-test returns `survives_if_narrowed`, `needs_pivot`, or `collapses`;
- the decision affects dissertation direction, opening report, journal submission, fund/proposal, or costly experiments;
- the user explicitly asks for multi-role conflict review.

De-escalate or stay low if:

- the user only wants a quick first impression;
- evidence is too thin for high-cost debate;
- the decision has no immediate resource consequence;
- only wording or title scope is being adjusted.

## Required gates

Every STANDARD or HIGH_RISK topic must pass through these gates:

1. `prior-art-topic-filter`: what has already been done?
2. `novelty-gate`: what exactly is new?
3. `feasibility-gate`: can the user realistically test it?
4. `collapse-test`: can the topic survive skeptical reduction?
5. `topic-arbiter`: final balanced decision.

## Collapse-test rules

Attack the topic with at least five reduction questions:

1. Is this only a material substitution?
2. Is this only a descriptor renaming exercise?
3. Is the proposed variable already confounded with processing conditions?
4. Can the hypothesis fail clearly?
5. Would the same conclusion be obtained by reading existing review papers?
6. Does the method create a publishable result, or only a dataset-cleaning exercise?
7. Does the topic depend on unavailable instruments, data, or long experimental timelines?

## Token discipline

Read only what is necessary for the current gate. Prefer compressed evidence packs and manifests over full-text reading. Escalate to multi-agent conflict only when the tiered trigger decision requires it.

## Output discipline

Never return vague encouragement. Every output must contain:

- selected evaluation mode: `LIGHT`, `STANDARD`, or `HIGH_RISK`;
- trigger reasons and non-trigger reasons;
- the current topic statement;
- strongest argument for continuing;
- strongest argument against continuing;
- missing evidence;
- required narrowing or pivot;
- final decision label, unless the user explicitly requested only quick ideation.
