Use $research-topic-selection-skill to validate this research topic:
"Composition-normalized screening of biomass hard-carbon precursors for sodium-ion battery first-cycle ICE."

Inputs:
- Field boundary: biomass-derived hard carbon anodes for sodium-ion batteries.
- Available evidence: Scopus abstracts, cleaned descriptor table, prior topic-audit notes.
- Capability: literature meta-analysis and small MVE experiment with controlled cellulose:lignin ratios.
- Decision consequence: possible thesis subtopic and advisor discussion.
- Target output: GO / REVISE / NARROW / PIVOT / KILL decision brief.

Use tiered triggering. Start with the lowest sufficient mode and escalate only if the trigger rules require it.
Run only the topic-selection workflow. Do not perform manuscript review.
