# Divergent Ideation Prompt Example

Use this prompt when the user says the generated topics are too similar.

Prompt:

Please enter Divergent Ideation Mode.

My broad field is biomass-derived or model hard-carbon anodes for sodium-ion batteries. Existing topic generation has become too concentrated around composition–ash–ICE–descriptor wording.

Known crowded axes:
- cellulose:lignin ratio
- Al2O3 mineral addition
- natural biomass impurity removal
- broad biomass precursor screening
- generic high-ICE hard-carbon optimization

Please brainstorm from 8 independent lenses:
1. precursor chemistry
2. pyrolysis pathway
3. pore accessibility and closed pores
4. surface/interface/SEI
5. electrolyte and formation protocol
6. electrode engineering and practical relevance
7. descriptor/statistical methodology
8. cross-system transferability

For each lens, generate 5 candidate directions.

For each candidate, include:
- English working title
- Chinese explanation
- core scientific question
- primary mechanism axis
- why it differs from the current Ca/Si ash timing topic
- collision risk
- feasibility score
- novelty score
- advisor-discussion value
- pilot suitability
- minimum experiment needed

Do not directly select a final topic.
First generate a topic pool, then perform a light collision pre-screen, then select 3–5 candidates for deeper evaluation.
