# Updated package note — v3

This refreshed zip keeps the pure research-topic-selection scope from v2 and adds a tiered triggering layer.

Included from v2:
- research-topic-selection workflow only, with manuscript review out of scope
- prior-art-topic-filter, novelty-gate, feasibility-gate, collapse-test, topic-arbiter
- Advocate / Skeptic / Arbiter conflict roles for high-risk topic decisions
- JSON schemas, prompts, scripts, example biomass-hard-carbon topic intake

New in v3:
- `tiered-trigger-router` skill
- `trigger_decision.schema.json`
- `route_evaluation_mode.py` helper script
- explicit LIGHT / STANDARD / HIGH_RISK execution modes
- optional high-risk auditors: `prior-art-auditor`, `methodology-auditor`, `feasibility-auditor`
- high-risk subagent configs for the three auditors
- updated prompts and examples for tiered triggering

Recommended workflow:

```text
research-topic-intake-router
→ tiered-trigger-router
→ LIGHT / STANDARD / HIGH_RISK branch
→ topic-arbiter
→ topic-brief-writer
→ workflow-archivist
```

Use this package when you want a research-type paper topic to be evaluated with token discipline: do not run all roles by default; escalate only when the topic decision is high-risk.
