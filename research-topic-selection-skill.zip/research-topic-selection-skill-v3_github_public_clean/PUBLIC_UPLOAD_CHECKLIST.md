# Public GitHub Upload Checklist

This package is a public-safe skeleton of `research-topic-selection-skill-v3`.

## Removed from the public package

- Raw literature export files under `literature/raw/`
- Processed literature records under `literature/processed/`
- Real task outputs under `tasks/`

These files may contain copyrighted abstracts, database-export metadata, unpublished research ideas, advisor-facing plans, or private project history. Keep them in a private repository or local workspace.

## Before publishing

1. Choose a license deliberately. If no license is added, the repository is effectively all-rights-reserved by default.
2. Keep `.agents/skills/` and `skills/` only if you need both compatibility layouts. They are mirrored copies.
3. Do not commit raw Scopus/Web of Science/Publisher exports unless you are sure the license permits redistribution.
4. Run the smoke tests below after cloning.

## Smoke tests

```bash
python -m py_compile scripts/*.py
python scripts/route_evaluation_mode.py examples/biomass_hard_carbon_topic_intake.json
python scripts/init_topic_task.py demo_topic
```

For literature ingestion, place your own private CSV/XLSX in `literature/raw/` locally, then run:

```bash
python scripts/ingest_literature_file.py --input literature/raw/your_file.csv
```
